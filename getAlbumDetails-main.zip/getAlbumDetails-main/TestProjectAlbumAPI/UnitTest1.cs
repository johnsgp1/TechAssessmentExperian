﻿using ApiTest.Controllers;
using ApiTest.Models;
using Microsoft.AspNetCore.Mvc;

namespace TestProjectAlbumAPI;

public class Tests
{
    [SetUp]
    public void Setup()
    {
    }

    /*Test case for get all data relating to UserId in request*/
    [Test]
    public void GetAlbumDetails_ShouldReturnSpecificAlbums()
    {
        //var testAlbumData = GetTestData();
        var controller = new PhotosController();
        string userId = "1";
        var Result = controller.GetAlbumDetails(userId);
        var okResult = Result as OkObjectResult;
        var newBatch = okResult.Value as List<Response>;
        Assert.AreEqual(500, newBatch.Count);
    }

    /*Test case for get all data in request*/
    [Test]
    public void GetAllAlbumDetails_ShouldReturnAllAlbums()
    {
        //var testAlbumData = GetTestData();
        var controller = new PhotosController();
        string userId = "";
        var Result = controller.GetAlbumDetails(userId);
        var okResult = Result as OkObjectResult;
        var newBatch = okResult.Value as List<Response>;
        Assert.AreEqual(5000, newBatch.Count);
    }

    private List<Response> GetTestData()
    {
        var testAlbumData = new List<Response>();
        testAlbumData.Add(new Response { userId = "1", albumId = "Demo1", url = "", thumbnailUrl = "" });
        testAlbumData.Add(new Response { userId = "1", albumId = "Demo2", url = "", thumbnailUrl = "" });
        testAlbumData.Add(new Response { userId = "1", albumId = "Demo3", url = "", thumbnailUrl = "" });
        testAlbumData.Add(new Response { userId = "1", albumId = "Demo4", url = "", thumbnailUrl = "" });

        return testAlbumData;
    }
}
